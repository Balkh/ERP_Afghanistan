"""
UI Testing Utilities and Fixtures.
Reusable test utilities for PySide6 UI testing.
"""

import pytest
from unittest.mock import MagicMock, patch
from typing import Dict, Any, List, Optional
from PySide6.QtCore import Qt, QTimer, QEvent, QPoint
from PySide6.QtWidgets import QApplication, QWidget
from PySide6.QtTest import QTest


class UITestHelpers:
    """Helper utilities for UI testing."""
    
    @staticmethod
    def wait_for_render(qtbot, timeout: int = 100):
        """Wait for widget to render."""
        qtbot.wait(timeout)
        
    @staticmethod
    def wait_for_signal(signal, timeout: int = 1000, raising: bool = True):
        """Wait for a signal to be emitted."""
        result = []
        signal.connect(lambda v: result.append(v))
        
        import time
        start = time.time()
        while not result and (time.time() - start) < timeout / 1000:
            QApplication.processEvents()
            
        if raising and not result:
            raise TimeoutError(f"Signal not emitted within {timeout}ms")
            
        return result[0] if result else None
        
    @staticmethod
    def click_button(qtbot, button):
        """Click a button and process events."""
        qtbot.click(button)
        QApplication.processEvents()
        
    @staticmethod
    def enter_text(qtbot, line_edit, text: str):
        """Enter text into a line edit."""
        line_edit.setFocus()
        line_edit.clear()
        qtbot.keyClicks(line_edit, text)
        QApplication.processEvents()
        
    @staticmethod
    def select_combo_item(qtbot, combo_box, text: str):
        """Select item in combo box."""
        combo_box.setCurrentText(text)
        QApplication.processEvents()
        
    @staticmethod
    def check_checkbox(qtbot, checkbox, checked: bool = True):
        """Set checkbox state."""
        if checkbox.isChecked() != checked:
            qtbot.click(checkbox)
            QApplication.processEvents()
            
    @staticmethod
    def double_click_item(qtbot, list_widget, index: int):
        """Double click item in list widget."""
        list_widget.setCurrentRow(index)
        QTest.keyClick(list_widget, Qt.Key.Key_Return)
        QApplication.processEvents()
        
    @staticmethod
    def simulate_key_sequence(qtbot, widget, keys: List[int]):
        """Simulate key press sequence."""
        for key in keys:
            QTest.keyClick(widget, key)
            QApplication.processEvents()
            
    @staticmethod
    def get_table_row_count(table) -> int:
        """Get number of rows in table."""
        return table.rowCount()
        
    @staticmethod
    def get_combobox_items(combo_box) -> List[str]:
        """Get all items in combo box."""
        return [combo_box.itemText(i) for i in range(combo_box.count())]
        
    @staticmethod
    def get_list_items(list_widget) -> List[str]:
        """Get all items in list widget."""
        return [list_widget.item(i).text() for i in range(list_widget.count())]


class WidgetTestData:
    """Test data generators for widgets."""
    
    @staticmethod
    def valid_product_data() -> Dict[str, Any]:
        """Generate valid product test data."""
        return {
            'name': 'Test Product',
            'sku': 'TEST-001',
            'generic_name': 'Test Generic',
            'brand_name': 'Test Brand',
            'category_id': 1,
            'unit_id': 1,
            'cost_price': 100.00,
            'sale_price': 150.00,
            'reorder_level': 10,
            'is_active': True
        }
        
    @staticmethod
    def valid_customer_data() -> Dict[str, Any]:
        """Generate valid customer test data."""
        return {
            'name': 'Test Customer',
            'code': 'CUST-001',
            'customer_type': 'RETAIL',
            'phone': '+93701234567',
            'email': 'test@example.com',
            'address': 'Test Address',
            'is_active': True
        }
        
    @staticmethod
    def valid_invoice_data() -> Dict[str, Any]:
        """Generate valid invoice test data."""
        return {
            'customer_id': 1,
            'invoice_date': '2025-01-01',
            'due_date': '2025-01-31',
            'items': [
                {'product_id': 1, 'quantity': 2, 'unit_price': 100.00}
            ]
        }
        
    @staticmethod
    def invalid_email_data() -> Dict[str, Any]:
        """Generate invalid email test data."""
        return {'email': 'invalid-email'}
        
    @staticmethod
    def invalid_phone_data() -> Dict[str, Any]:
        """Generate invalid phone test data."""
        return {'phone': '123'}


class FormValidationTester:
    """Test form validation patterns."""
    
    def __init__(self, qtbot):
        self.qtbot = qtbot
        self.errors = []
        
    def test_required_field(self, field, value: str = ""):
        """Test required field validation."""
        field.set_value(value)
        is_valid, msg = field.validate()
        if is_valid:
            self.errors.append(f"Field should require value but passed")
            
    def test_email_validation(self, field, invalid_email: str):
        """Test email validation."""
        field.set_value(invalid_email)
        is_valid, msg = field.validate()
        if is_valid:
            self.errors.append(f"Invalid email '{invalid_email}' should fail validation")
            
    def test_numeric_validation(self, field, invalid_value: str):
        """Test numeric field validation."""
        field.set_value(invalid_value)
        is_valid, msg = field.validate()
        if is_valid:
            self.errors.append(f"Invalid numeric value '{invalid_value}' should fail")
            
    def get_errors(self) -> List[str]:
        """Get validation errors."""
        return self.errors


class TableTestHelper:
    """Helper for testing table/grid components."""
    
    def __init__(self, table):
        self.table = table
        
    def get_row_count(self) -> int:
        """Get table row count."""
        return self.table.rowCount()
        
    def get_column_count(self) -> int:
        """Get table column count."""
        return self.table.columnCount()
        
    def get_cell_text(self, row: int, col: int) -> str:
        """Get cell text at position."""
        item = self.table.item(row, col)
        return item.text() if item else ""
        
    def get_selected_rows(self) -> List[int]:
        """Get selected row indices."""
        return [idx.row() for idx in self.table.selectedIndexes()]
        
    def select_row(self, qtbot, row: int):
        """Select row."""
        self.table.selectRow(row)
        QApplication.processEvents()
        
    def double_click_cell(self, qtbot, row: int, col: int):
        """Double click cell."""
        self.table.setCurrentCell(row, col)
        from PySide6.QtTest import QTest
        QTest.mouseDClick(self.table.viewport(), Qt.LeftButton, Qt.NoModifier, 
                         self.table.visualColumnRect(col).center())
        QApplication.processEvents()


class NavigationTestHelper:
    """Helper for testing navigation."""
    
    def __init__(self, sidebar):
        self.sidebar = sidebar
        
    def click_menu_item(self, qtbot, index: int):
        """Click menu item by index."""
        from PySide6.QtTest import QTest
        # Implementation depends on sidebar structure
        pass
        
    def verify_navigation(self, expected_screen: str) -> bool:
        """Verify navigation occurred."""
        # Check if correct screen is displayed
        return True


class PerformanceTestHelper:
    """Helper for performance testing."""
    
    @staticmethod
    def measure_render_time(widget) -> float:
        """Measure widget render time in milliseconds."""
        import time
        
        # Ensure widget is shown
        widget.show()
        QApplication.processEvents()
        
        start = time.perf_counter()
        QApplication.processEvents()
        end = time.perf_counter()
        
        return (end - start) * 1000
        
    @staticmethod
    def test_table_performance(table, row_count: int) -> Dict[str, float]:
        """Test table performance with large dataset."""
        import time
        
        # Measure add rows
        start = time.perf_counter()
        # Add rows...
        add_time = (time.perf_counter() - start) * 1000
        
        # Measure selection
        start = time.perf_counter()
        table.selectAll()
        select_time = (time.perf_counter() - start) * 1000
        
        return {
            'add_rows_ms': add_time,
            'select_all_ms': select_time
        }


class KeyboardWorkflowTester:
    """Test keyboard workflows."""
    
    def __init__(self, qtbot):
        self.qtbot = qtbot
        
    def test_tab_navigation(self, widget):
        """Test tab key navigation."""
        widget.setFocus()
        for _ in range(5):
            QTest.keyClick(widget, Qt.Key.Key_Tab)
            QApplication.processEvents()
            
    def test_enter_submit(self, form):
        """Test Enter key submits form."""
        form.setFocus()
        QTest.keyClick(form, Qt.Key.Key_Return)
        QApplication.processEvents()
        
    def test_escape_cancel(self, dialog):
        """Test Escape key cancels dialog."""
        dialog.setFocus()
        QTest.keyClick(dialog, Qt.Key.Key_Escape)
        QApplication.processEvents()
        
    def test_ctrl_s_save(self, widget):
        """Test Ctrl+S saves."""
        widget.setFocus()
        QTest.keyClick(widget, Qt.Key.Key_S, Qt.KeyboardModifier.ControlModifier)
        QApplication.processEvents()


# Pytest fixtures for new components

@pytest.fixture
def enterprise_button(qtbot):
    """Create enterprise button for testing."""
    from ui.components.buttons import EnterpriseButton, ButtonVariant, ButtonSize
    button = EnterpriseButton(
        text="Test Button",
        variant=ButtonVariant.PRIMARY,
        size=ButtonSize.MEDIUM
    )
    qtbot.addWidget(button)
    return button
    
@pytest.fixture
def enterprise_table(qtbot):
    """Create enterprise table for testing."""
    from ui.components.tables import EnterpriseTable, TableColumn
    
    columns = [
        TableColumn("id", "ID", 50),
        TableColumn("name", "Name", 200),
        TableColumn("price", "Price", 100)
    ]
    
    table = EnterpriseTable(columns)
    qtbot.addWidget(table)
    return table
    
@pytest.fixture
def form_field(qtbot):
    """Create form field for testing."""
    from ui.components.forms import FormField, FieldType
    
    field = FormField(
        field_type=FieldType.TEXT,
        label="Test Field",
        name="test_field",
        required=True
    )
    qtbot.addWidget(field)
    return field
    
@pytest.fixture
def notification_manager(qtbot):
    """Create notification manager for testing."""
    from ui.components.notifications import NotificationManager
    manager = NotificationManager()
    return manager
    
@pytest.fixture
def locale_manager():
    """Create locale manager for testing."""
    from i18n.localization import LocaleManager, Language
    manager = LocaleManager()
    return manager
    
@pytest.fixture
def date_formatter():
    """Create date formatter for testing."""
    from i18n.localization import DateFormatter, DateFormat
    return DateFormatter
    
@pytest.fixture
def currency_formatter():
    """Create currency formatter for testing."""
    from i18n.localization import CurrencyFormatter
    return CurrencyFormatter