from PySide6.QtWidgets import QVBoxLayout, QLabel
from ui.constants import TEXT_PAGE_TITLE, COLOR_TEXT_PRIMARY, SPACING_XXL, FONT_WEIGHT_BOLD
from ui.screens.base_screen import BaseScreen


class SystemIntegrityScreen(BaseScreen):
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(SPACING_XXL, SPACING_XXL, SPACING_XXL, SPACING_XXL)
        title = QLabel("System Integrity")
        title.setStyleSheet(f"font-size: {TEXT_PAGE_TITLE}pt; font-weight: {FONT_WEIGHT_BOLD}; color: {COLOR_TEXT_PRIMARY};")
        layout.addWidget(title)
        info = QLabel("System integrity monitoring is available via the backend API.")
        info.setWordWrap(True)
        info.setStyleSheet(f"color: {COLOR_TEXT_PRIMARY};")
        layout.addWidget(info)
        layout.addStretch()

    def _on_screen_shown(self):
        pass

    def _on_screen_hidden(self):
        pass
