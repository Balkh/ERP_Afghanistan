"""User Management Screen for ERP."""
from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout,
                                  QLabel, QAbstractItemView, QComboBox,
                                  QLineEdit,
                                  QCheckBox, QTabWidget,
                                  QWidget)
from PySide6.QtCore import Qt
from PySide6.QtGui import QFont, QKeySequence, QShortcut
from ui.screens.base_screen import BaseScreen
from ui.components.buttons import EnterpriseButton, ButtonVariant, ButtonSize
from ui.components.tables import EnterpriseTable, TableColumn
from ui.components.dialogs import EnterpriseDialog, DialogType, AlertDialog, ConfirmDialog
from ui.components.forms import FormSection
from ui.constants import (SPACING_XS, SPACING_SM, SPACING_MD, SPACING_LG, SPACING_XL, SPACING_XXL, MARGIN_PAGE, TEXT_CARD_TITLE,
                           TEXT_BODY, BORDER_RADIUS_SM, BORDER_RADIUS_MD, BORDER_RADIUS_LG, COLOR_BG_MAIN, COLOR_BG_ELEVATED, COLOR_BORDER, COLOR_TABLE_HEADER_BG_LIGHT, COLOR_TEXT_PRIMARY,
                           COLOR_TEXT_MUTED, COLOR_PRIMARY, COLOR_SUCCESS, FONT_NAME_PRIMARY)
from .user_dialog import UserDialog



class UserManagementScreen(BaseScreen):
    """User management screen with CRUD operations."""
    
    def __init__(self, parent=None, screen_id="user_management", config=None, api_client=None):
        super().__init__(parent, screen_id, config)
        self._api_client = api_client
        self._users = []
        self._roles = []
        self._setup_ui()
        self.load_users()
        self.load_roles()
    
    def _setup_ui(self):
        """Setup the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE)
        layout.setSpacing(SPACING_LG)

        # Header section
        header_layout = QHBoxLayout()
        from theme.style_builder import UIStyleBuilder
        header = QLabel("User & Role Management")
        header.setStyleSheet(UIStyleBuilder.get_label_style("title"))
        header_layout.addWidget(header)
        
        header_layout.addStretch()
        
        self.btn_refresh = EnterpriseButton(text="\u27f3 Refresh", variant=ButtonVariant.SECONDARY, size=ButtonSize.MEDIUM)
        self.btn_refresh.clicked.connect(self.load_users)
        header_layout.addWidget(self.btn_refresh)
        layout.addLayout(header_layout)
        
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(UIStyleBuilder.get_tab_style())
        
        # Users Tab
        self.users_tab = QWidget()
        self._setup_users_tab()
        self.tabs.addTab(self.users_tab, "System Users")
        
        # Roles & Permissions Tab
        self.roles_tab = QWidget()
        self._setup_roles_tab()
        self.tabs.addTab(self.roles_tab, "Roles & Permissions")
        
        layout.addWidget(self.tabs)
    
    def _setup_users_tab(self):
        layout = QVBoxLayout(self.users_tab)
        layout.setContentsMargins(SPACING_LG,  SPACING_LG,  SPACING_LG,  SPACING_LG)
        layout.setSpacing(SPACING_LG)
        
        action_layout = QHBoxLayout()
        self.add_user_btn = EnterpriseButton(text="+ Create User", variant=ButtonVariant.SUCCESS, size=ButtonSize.MEDIUM)
        self.add_user_btn.clicked.connect(self.add_user)
        action_layout.addWidget(self.add_user_btn)
        action_layout.addStretch()
        layout.addLayout(action_layout)
        
        columns = [
            TableColumn("id", "ID", width=50),
            TableColumn("username", "Username", width=120),
            TableColumn("email", "Email", width=180),
            TableColumn("first_name", "First Name", width=100),
            TableColumn("last_name", "Last Name", width=100),
            TableColumn("role", "Role", width=100),
            TableColumn("active", "Active", width=60, align="center"),
        ]
        self.user_table = self._create_modern_table(columns)
        layout.addWidget(self.user_table)
        
        self.load_users()

    def _setup_roles_tab(self):
        layout = QVBoxLayout(self.roles_tab)
        layout.setContentsMargins(SPACING_LG,  SPACING_LG,  SPACING_LG,  SPACING_LG)
        layout.setSpacing(SPACING_LG)
        
        from theme.style_builder import UIStyleBuilder
        info_label = QLabel("System Roles are predefined based on organizational functions. You can view permissions for each role below.")
        info_label.setStyleSheet(UIStyleBuilder.get_label_style("muted") + " font-style: italic;")
        layout.addWidget(info_label)
        
        role_selector_layout = QHBoxLayout()
        role_selector_layout.addWidget(QLabel("Select Role to View:"))
        self.role_selector = QComboBox()
        # Pre-populate with roles from UserRole enum
        from ui.role_manager import UserRole
        for role in UserRole:
            self.role_selector.addItem(role.name.replace('_', ' ').title(), role)
        
        self.role_selector.setMinimumWidth(200)
        self.role_selector.currentIndexChanged.connect(self._on_role_selected)
        role_selector_layout.addWidget(self.role_selector)
        role_selector_layout.addStretch()
        layout.addLayout(role_selector_layout)
        
        perm_columns = [
            TableColumn("module", "Module", width=200),
            TableColumn("permission", "Permission", width=150),
            TableColumn("access", "Access Level", width=100),
        ]
        self.permissions_table = self._create_modern_table(perm_columns)
        layout.addWidget(self.permissions_table)
        
        # Initial role selection
        self._on_role_selected(0)

    def _create_modern_table(self, columns=None):
        """Create a modern dark-themed table."""
        if columns:
            table = EnterpriseTable(columns)
        else:
            table = EnterpriseTable([TableColumn(f"col{i}", "") for i in range(4)])
        table.setAlternatingRowColors(True)
        table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.setMinimumHeight(200)
        return table

    def _on_role_selected(self, index):
        role = self.role_selector.currentData()
        if not role: return
        
        from ui.role_manager import ROLE_PERMISSIONS
        permissions = ROLE_PERMISSIONS.get(role, [])
        
        data = []
        for perm in permissions:
            parts = perm.split('.')
            module = parts[0].title() if len(parts) > 0 else ""
            action = parts[1].replace('_', ' ').title() if len(parts) > 1 else ""
            data.append({
                "module": module,
                "permission": action,
                "access": "Full Access" if 'admin' in perm else "Standard",
            })
        self.permissions_table.set_data(data)
    
    def load_roles(self):
        """Load roles from API."""
        if not self._api_client:
            return
        try:
            result = self._api_client.get_roles()
            if result.get('success'):
                self._roles = result.get('data', [])
        except Exception as e:
            # TODO: Replace with user-facing error state (no error_label/empty_label available)
            print(f"Error loading roles: {e}")
    
    def load_users(self):
        """Load users from API."""
        if not self._api_client:
            return
        
        try:
            result = self._api_client.get_users()
            if result.get('success'):
                self._users = result.get('data', {}).get('results', [])
                self.populate_table()
        except Exception as e:
            # TODO: Replace with user-facing error state (no error_label/empty_label available)
            print(f"Error loading users: {e}")
    
    def populate_table(self):
        """Populate the users table."""
        data = [
            {
                "id": str(u.get('id', '')),
                "username": u.get('username', ''),
                "email": u.get('email', ''),
                "first_name": u.get('first_name', ''),
                "last_name": u.get('last_name', ''),
                "role": ", ".join(u.get('roles', [])) if u.get('roles') else "General",
                "active": "Yes" if u.get('is_active', True) else "No",
            }
            for u in self._users
        ]
        self.user_table.set_data(data)
    
    def add_user(self):
        """Show add user dialog."""
        dialog = UserDialog(self._api_client, parent=self)
        if dialog.exec():
            self.load_users()

    def edit_user(self):
        """Show edit user dialog."""
        selected = self.user_table.selectedItems()
        if not selected: return
        row = selected[0].row()
        user_data = self._users[row] if row < len(self._users) else None
        
        if user_data:
            dialog = UserDialog(self._api_client, parent=self, user_data=user_data)
            if dialog.exec():
                self.load_users()

    def delete_user(self):
        """Delete selected user."""
        selected = self.user_table.selectedItems()
        if not selected: return
        row = selected[0].row()
        user_data = self._users[row]
        
        reply = ConfirmDialog.confirm(
            "Delete User",
            f"Are you sure you want to delete user '{user_data.get('username')}'?",
            self
        )
        
        if reply:
            try:
                self._api_client.delete(f"/api/auth/users/{user_data['id']}/")
                self.load_users()
            except Exception as e:
                AlertDialog.error("Error", f"Failed to delete user: {e}", self)
