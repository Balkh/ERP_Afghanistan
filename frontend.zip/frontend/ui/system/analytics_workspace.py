"""
AnalyticsWorkspace — consolidated intelligence/analytics hub.
Hosts: Integrity, Workflow Intel, Drift, Correlation, Event Store, Investigations.
"""

from PySide6.QtWidgets import QVBoxLayout, QTabWidget, QLabel
from ui.constants import (MARGIN_PAGE, SPACING_MD,
                           TEXT_PAGE_TITLE, COLOR_TEXT_PRIMARY, FONT_WEIGHT_BOLD)
from ui.system.integrity_screen import SystemIntegrityScreen
from ui.system.workflow_intelligence_screen import WorkflowIntelligenceScreen
from ui.system.drift_intelligence_screen import DriftIntelligenceScreen
from ui.system.correlation_screen import SystemCorrelationScreen
from ui.truth.event_store_screen import EventStoreScreen
from ui.investigation.anomaly_investigation_screen import AnomalyInvestigationScreen
from ui.investigation.event_investigation_screen import EventInvestigationScreen
from ui.screens.base_screen import BaseScreen


class AnalyticsWorkspace(BaseScreen):
    """Single unified workspace for all ERP analytical views."""

    def __init__(self, parent=None):
        super().__init__(parent, screen_id="analytics_workspace")

    def _setup_screen(self):
        super()._setup_screen()
        layout = QVBoxLayout(self)
        layout.setContentsMargins(MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE)
        layout.setSpacing(SPACING_MD)

        header = QLabel("Analytics & Intelligence")
        header.setStyleSheet(f"color: {COLOR_TEXT_PRIMARY}; font-size: {TEXT_PAGE_TITLE}pt; font-weight: {FONT_WEIGHT_BOLD};")
        layout.addWidget(header)

        tabs = QTabWidget()
        tabs.addTab(SystemIntegrityScreen(), "System Integrity")
        tabs.addTab(WorkflowIntelligenceScreen(), "Workflow Intelligence")
        tabs.addTab(DriftIntelligenceScreen(), "Drift Detection")
        tabs.addTab(SystemCorrelationScreen(), "Correlation")
        tabs.addTab(EventStoreScreen(), "Event Store")
        tabs.addTab(AnomalyInvestigationScreen(), "Anomaly Investigation")
        tabs.addTab(EventInvestigationScreen(), "Event Investigation")
        layout.addWidget(tabs)

    def _on_screen_shown(self):
        pass
