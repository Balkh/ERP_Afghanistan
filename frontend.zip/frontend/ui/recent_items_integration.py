"""
Recent Items & Pinned Items System - Sprint 3.4

Minimal integration that enhances existing navigation with recent screens
and pinned items functionality.

Key Design Principles:
- Leverages existing navigation infrastructure (NavigationHistory, Sidebar)
- Minimal code changes to existing files
- User-scoped storage (JSON files)
- Backward compatible
- Performance optimized

Architecture:
1. RecentItemsIntegration: Integrates with NavigationHistory and Sidebar
2. PinnedItemsManager: Manages pinned items
3. Integration Hooks: Add recent item tracking to existing navigation
"""

import json
import logging
import os
from typing import List, Dict, Optional
from datetime import datetime

logger = logging.getLogger(__name__)


class RecentItemsIntegration:
    """Integration layer for recent items functionality."""
    
    def __init__(self, storage_file: str = ""):
        self.storage_file = storage_file if storage_file else self._get_default_storage_file()
        self._ensure_storage_exists()
        self._load_data()
    
    def _get_default_storage_file(self) -> str:
        """Get default storage file path."""
        config_dir = os.path.expanduser("~/.config/pharmacy_erp")
        os.makedirs(config_dir, exist_ok=True)
        return os.path.join(config_dir, "recent_items_storage.json")
    
    def _ensure_storage_exists(self):
        """Create storage file if it doesn't exist."""
        if not os.path.exists(self.storage_file):
            self._save_data({
                "recent_screens": {},
                "pinned_items": {}
            })
    
    def _load_data(self) -> Dict:
        """Load data from storage."""
        try:
            with open(self.storage_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError, OSError):
            return {"recent_screens": {}, "pinned_items": {}}
    
    def _save_data(self, data: Dict):
        """Save data to storage."""
        try:
            with open(self.storage_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, default=str)
        except OSError as e:
            logger.error("Failed to save recent items to %s: %s", self.storage_file, e)
    
    def add_recent_screen(self, index: int, title: str, screen_id: str) -> None:
        """Add screen to recent items."""
        data = self._load_data()
        item_id = f"screen_{screen_id}"
        
        data["recent_screens"][item_id] = {
            "index": index,
            "title": title,
            "screen_id": screen_id,
            "last_accessed": datetime.now().isoformat(),
            "type": "screen"
        }
        
        # Keep only most recent items
        if len(data["recent_screens"]) > 10:
            items = sorted(data["recent_screens"].items(), 
                         key=lambda x: x[1]["last_accessed"], reverse=True)
            data["recent_screens"] = dict(items[:10])
        
        self._save_data(data)
    
    def toggle_pin(self, item_type: str, item_id: str, title: str) -> bool:
        """Toggle pin state for an item.
        
        Returns:
            True if item is now pinned, False if unpinned
        """
        data = self._load_data()
        data.setdefault("pinned_items", {})
        
        full_item_id = f"{item_type}_{item_id}"
        
        if full_item_id in data["pinned_items"]:
            # Unpin
            del data["pinned_items"][full_item_id]
            return False
        else:
            # Pin
            data["pinned_items"][full_item_id] = {
                "type": item_type,
                "title": title,
                "pinned_at": datetime.now().isoformat()
            }
            self._save_data(data)
            return True
    
    def is_pinned(self, item_type: str, item_id: str) -> bool:
        """Check if item is pinned."""
        data = self._load_data()
        full_item_id = f"{item_type}_{item_id}"
        return full_item_id in data.get("pinned_items", {})
    
    def get_recent_screens(self) -> List[Dict]:
        """Get recent screens sorted by last access."""
        data = self._load_data()
        screens = data.get("recent_screens", {})
        items = list(screens.values())
        items.sort(key=lambda x: x["last_accessed"], reverse=True)
        return items
    
    def get_pinned_items(self, item_type: str) -> List[Dict]:
        """Get pinned items of a specific type."""
        data = self._load_data()
        pinned = data.get("pinned_items", {})
        
        result = []
        for item_id, item_data in pinned.items():
            if item_data["type"] == item_type:
                result.append({
                    "id": item_id,
                    "title": item_data["title"],
                    "type": item_data["type"],
                    "pinned_at": item_data["pinned_at"]
                })
        return result


# Global instance
_recent_items_integration: Optional[RecentItemsIntegration] = None


def get_recent_items_integration() -> RecentItemsIntegration:
    """Get or create the global integration instance."""
    global _recent_items_integration
    if _recent_items_integration is None:
        _recent_items_integration = RecentItemsIntegration()
    return _recent_items_integration


def init_recent_items() -> None:
    """Initialize the recent items system."""
    get_recent_items_integration()


def add_recent_screen(index: int, title: str, screen_id: str) -> None:
    """Add a screen to recent items (convenience function)."""
    get_recent_items_integration().add_recent_screen(index, title, screen_id)

def toggle_pin(item_type: str, item_id: str, title: str) -> bool:
    """Toggle pin state (convenience function)."""
    return get_recent_items_integration().toggle_pin(item_type, item_id, title)

def is_pinned(item_type: str, item_id: str) -> bool:
    """Check if item is pinned (convenience function)."""
    return get_recent_items_integration().is_pinned(item_type, item_id)

def get_recent_screens() -> List[Dict]:
    """Get recent screens (convenience function)."""
    return get_recent_items_integration().get_recent_screens()

def get_pinned_items(item_type: str) -> List[Dict]:
    """Get pinned items (convenience function)."""
    return get_recent_items_integration().get_pinned_items(item_type)