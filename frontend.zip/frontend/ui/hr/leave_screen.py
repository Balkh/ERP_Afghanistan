"""Leave management screen for ERP."""
from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout,
                                 QLabel, QLineEdit)
from PySide6.QtCore import Qt
from api.client import APIClient
from api.endpoints import get_endpoint, extract_list
from ui.screens.base_screen import BaseScreen, ScreenState
from ui.constants import (SPACING_SM, SPACING_MD, MARGIN_PAGE, TEXT_PAGE_TITLE, COLOR_TEXT_PRIMARY)
from ui.components.buttons import EnterpriseButton, ButtonVariant, ButtonSize
from ui.components.tables import EnterpriseTable, TableColumn
from ui.components.state_helper import StateHelper
from ui.utils.debounce import Debouncer


class LeaveScreen(BaseScreen):
    """Leave management screen."""
    
    def __init__(self, parent=None, api_client=None):
        super().__init__(parent, screen_id="leave_screen")
        if api_client is None:
            raise ValueError("api_client is required for LeaveScreen")
        self.api_client = api_client
        self.leave_records = []
        self.setup_ui()
        self.load_leave()
    
    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE)
        layout.setSpacing(SPACING_MD)
         
        header = QLabel("Leave Management")
        header.setStyleSheet(f"color: {COLOR_TEXT_PRIMARY}; font-size: {TEXT_PAGE_TITLE}pt; font-weight: 700;")
        header.setContentsMargins(0, 0, 0, SPACING_SM)
        layout.addWidget(header)
         
        toolbar = QHBoxLayout()
        toolbar.setSpacing(SPACING_SM)
         
        refresh_btn = EnterpriseButton(text="\u27f3 Refresh", variant=ButtonVariant.SECONDARY, size=ButtonSize.MEDIUM)
        refresh_btn.clicked.connect(self.load_leave)
        toolbar.addWidget(refresh_btn)
         
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search by employee or leave type...")
        self.search_input.setMinimumHeight(35)
        self._leave_search_debounce = Debouncer(self.filter_leave, 300)
        self.search_input.textChanged.connect(self._leave_search_debounce)
        toolbar.addWidget(self.search_input)
         
        layout.addLayout(toolbar)
        
        # State management
        self._state_helper = StateHelper(layout)
         
        columns = [
            TableColumn("id", "ID", width=60),
            TableColumn("employee_name", "Employee", width=150),
            TableColumn("leave_type", "Type", width=100),
            TableColumn("start_date", "Start Date", width=100, align="center"),
            TableColumn("end_date", "End Date", width=100, align="center"),
            TableColumn("total_days", "Days", width=50, align="center"),
            TableColumn("status", "Status", width=80),
        ]
        self.table = EnterpriseTable(columns)
        layout.addWidget(self.table)
    
    def load_leave(self):
        """Load leave from API."""
        self.set_state(ScreenState.LOADING)
        try:
            endpoint = get_endpoint("leave")
            response = self.api_client.get(endpoint, background=True)
            self.leave_records = extract_list(response)
            
            # Update state based on data
            if len(self.leave_records) == 0:
                self.set_state(ScreenState.EMPTY)
            else:
                self.set_state(ScreenState.READY)
        except Exception as e:
            self.leave_records = []
            self.set_state(ScreenState.ERROR)
            self._error_message = f"Error loading leave: {e}"
        
        self.update_table()
    
    def update_table(self):
        """Update table with leave data and show appropriate state indicators."""
        state = self.state

        if state == ScreenState.LOADING:
            self._state_helper.show_loading()
            self.table.setVisible(False)
        elif state == ScreenState.ERROR:
            self._state_helper.show_error(
                getattr(self, '_error_message', 'Error loading leave records'),
                on_retry=self.load_leave
            )
            self.table.setVisible(False)
        elif state == ScreenState.EMPTY:
            self._state_helper.show_empty(
                "No leave records found",
                "Leave requests will appear here once submitted"
            )
            self.table.setVisible(False)
        else:
            self._state_helper.hide()
            self.table.setVisible(True)

        self.table.set_data(self._build_leave_data())
    
    def _build_leave_data(self):
        data = []
        for record in self.leave_records:
            data.append({
                "id": str(record.get('id', ''))[:8],
                "employee_name": record.get('employee_name', ''),
                "leave_type": record.get('leave_type', ''),
                "start_date": str(record.get('start_date', ''))[:10],
                "end_date": str(record.get('end_date', ''))[:10],
                "total_days": str(record.get('total_days', 0)),
                "status": record.get('status', ''),
            })
        return data
    
    def filter_leave(self, text):
        """Filter leave records by search text."""
        all_data = self._build_leave_data()

        if not text:
            self.table.set_data(all_data)
            return

        filtered = [r for r in all_data if text.lower() in str(r.get('employee_name', '')).lower() or text.lower() in str(r.get('leave_type', '')).lower()]
        self.table.set_data(filtered)