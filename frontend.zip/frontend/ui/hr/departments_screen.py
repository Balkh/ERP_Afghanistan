"""Departments and Positions management screen."""
from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
                                QComboBox, QWidget, QTabWidget)
from PySide6.QtCore import Qt
from PySide6.QtGui import QKeySequence, QShortcut
from api.client import APIClient
from api.endpoints import get_endpoint
from ui.screens.base_screen import BaseScreen, ScreenState
from ui.constants import (SPACING_SM, SPACING_MD, MARGIN_PAGE,
                           TEXT_PAGE_TITLE, COLOR_TEXT_PRIMARY)
from ui.components.buttons import EnterpriseButton, ButtonVariant, ButtonSize
from ui.components.tables import EnterpriseTable, TableColumn
from ui.components.dialogs import EnterpriseDialog, DialogType, AlertDialog, ConfirmDialog
from ui.components.forms import FormSection
from ui.components.state_helper import StateHelper
from ui.utils.validation import FormValidator
from ui.constants import INPUT_HEIGHT_MD
from theme.style_builder import UIStyleBuilder


class DepartmentsScreen(BaseScreen):
    """Screen for managing departments and positions."""

    def __init__(self, parent=None, api_client=None):
        super().__init__(parent, screen_id="departments")
        if api_client is None:
            raise ValueError("api_client is required for DepartmentsScreen")
        self.api_client = api_client
        self.departments = []
        self.positions = []
        self.setup_ui()
        self.load_data()

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE)
        layout.setSpacing(SPACING_MD)

        header = QHBoxLayout()
        title = QLabel("Departments & Positions")
        title.setStyleSheet(f"color: {COLOR_TEXT_PRIMARY}; font-size: {TEXT_PAGE_TITLE}pt; font-weight: 700;")
        header.addWidget(title)
        header.addStretch()
        self.refresh_btn = EnterpriseButton(text="Refresh", variant=ButtonVariant.SECONDARY, size=ButtonSize.MEDIUM)
        self.refresh_btn.clicked.connect(self.load_data)
        header.addWidget(self.refresh_btn)
        layout.addLayout(header)

        # State management
        self._state_helper = StateHelper(layout)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(UIStyleBuilder.get_tab_style())

        self.dept_tab = QWidget()
        self._setup_dept_tab()
        self.tabs.addTab(self.dept_tab, "Departments")

        self.pos_tab = QWidget()
        self._setup_pos_tab()
        self.tabs.addTab(self.pos_tab, "Positions")

        layout.addWidget(self.tabs)

    def _setup_dept_tab(self):
        layout = QVBoxLayout(self.dept_tab)
        layout.setSpacing(SPACING_MD)

        btn_layout = QHBoxLayout()
        add_btn = EnterpriseButton("+ Add Department", variant=ButtonVariant.SUCCESS, size=ButtonSize.MEDIUM)
        add_btn.clicked.connect(self._add_department)
        btn_layout.addWidget(add_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        self.dept_table = EnterpriseTable([
            TableColumn("code", "Code", width=80),
            TableColumn("name", "Name", width=200),
            TableColumn("parent", "Parent", width=150),
            TableColumn("manager", "Manager", width=150),
            TableColumn("status", "Status", width=80, align="center"),
        ])
        layout.addWidget(self.dept_table)

    def _setup_pos_tab(self):
        layout = QVBoxLayout(self.pos_tab)
        layout.setSpacing(SPACING_MD)

        btn_layout = QHBoxLayout()
        add_btn = EnterpriseButton("+ Add Position", variant=ButtonVariant.SUCCESS, size=ButtonSize.MEDIUM)
        add_btn.clicked.connect(self._add_position)
        btn_layout.addWidget(add_btn)
        btn_layout.addStretch()
        layout.addLayout(btn_layout)

        self.pos_table = EnterpriseTable([
            TableColumn("code", "Code", width=80),
            TableColumn("title", "Title", width=200),
            TableColumn("department", "Department", width=150),
            TableColumn("status", "Status", width=80, align="center"),
        ])
        layout.addWidget(self.pos_table)

    def load_data(self):
        self._load_departments()
        self._load_positions()

    def _update_state_indicators(self, success=True, has_data=True):
        state = self.state
        if state == ScreenState.LOADING:
            self._state_helper.show_loading()
            self.tabs.setVisible(False)
        elif not success:
            self._state_helper.show_error(
                "Error loading data",
                on_retry=self.load_data
            )
            self.tabs.setVisible(False)
        elif not has_data:
            self._state_helper.show_empty(
                "No data available",
                "Departments and positions will appear here once created"
            )
            self.tabs.setVisible(False)
        else:
            self._state_helper.hide()
            self.tabs.setVisible(True)

    def _load_departments(self):
        self.set_state(ScreenState.LOADING)
        try:
            response = self.api_client.get(get_endpoint("departments"), background=True)
            if response and isinstance(response, dict) and response.get("success"):
                raw = response.get("data", [])
                self.departments = raw.get("results", []) if isinstance(raw, dict) else raw
            else:
                self.departments = []
            
            has_data = bool(self.departments)
            self.set_state(ScreenState.READY if has_data else ScreenState.EMPTY)
            self._update_state_indicators(True, has_data)
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"Failed to load departments: {e}")
            self.departments = []
            self.set_state(ScreenState.ERROR)
            self._update_state_indicators(False, False)

        data = [{"code": d.get("code", ""), "name": d.get("name", ""),
                 "parent": d.get("parent_name", ""), "manager": d.get("manager_name", ""),
                 "status": "Active" if d.get("is_active") else "Inactive"} for d in self.departments]
        self.dept_table.set_data(data)

    def _load_positions(self):
        try:
            response = self.api_client.get(get_endpoint("positions"), background=True)
            if response and isinstance(response, dict) and response.get("success"):
                raw = response.get("data", [])
                self.positions = raw.get("results", []) if isinstance(raw, dict) else raw
            else:
                self.positions = []
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"Failed to load positions: {e}")
            self.positions = []

        data = [{"code": p.get("code", ""), "title": p.get("title", ""),
                 "department": p.get("department_name", ""),
                 "status": "Active" if p.get("is_active") else "Inactive"} for p in self.positions]
        self.pos_table.set_data(data)

    def _add_department(self):
        dialog = DepartmentDialog(api_client=self.api_client, parent=self)
        if dialog.exec():
            self._load_departments()

    def _add_position(self):
        dialog = PositionDialog(api_client=self.api_client, departments=self.departments, parent=self)
        if dialog.exec():
            self._load_positions()


class DepartmentDialog(EnterpriseDialog):
    def __init__(self, api_client=None, department=None, parent=None):
        self._api_client = api_client
        self._dept = department
        self._submitting = False
        super().__init__("Edit Department" if department else "Add Department", DialogType.CUSTOM, parent)
        self.setMinimumWidth(400)
        self.set_content(self._build_content())
        enter_shortcut = QShortcut(QKeySequence(Qt.Key_Return), self)
        enter_shortcut.activated.connect(self._save)
        self.code.setFocus()

    def _create_button_area(self):
        return None

    def _build_content(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)

        section = FormSection("Department Details", primary=True)

        self.code = QLineEdit()
        self.code.setPlaceholderText("DEPT")
        self.code.setMinimumHeight(INPUT_HEIGHT_MD)

        self.name = QLineEdit()
        self.name.setPlaceholderText("Department name")
        self.name.setMinimumHeight(INPUT_HEIGHT_MD)

        if self._dept:
            self.code.setText(self._dept.get("code", ""))
            self.name.setText(self._dept.get("name", ""))

        section.add_field(self.code, "Code*:")
        section.add_field(self.name, "Name*:")
        layout.addWidget(section)

        layout.addStretch()
        btn = QHBoxLayout()
        btn.setSpacing(SPACING_SM)
        btn.addStretch()
        cancel = EnterpriseButton("Cancel", variant=ButtonVariant.SECONDARY, size=ButtonSize.MEDIUM)
        cancel.clicked.connect(self.reject)
        save = EnterpriseButton("Save", variant=ButtonVariant.PRIMARY, size=ButtonSize.MEDIUM)
        save.clicked.connect(self._save)
        btn.addWidget(cancel)
        btn.addWidget(save)
        layout.addLayout(btn)
        return widget

    def _save(self):
        if self._submitting:
            return
        self._submitting = True

        validator = FormValidator()
        validator.validate_required("Code", self.code.text().strip(), "Code is required")
        validator.validate_required("Name", self.name.text().strip(), "Name is required")
        if validator.has_errors():
            error_messages = "\n".join([f"• {msg}" for msg in validator.get_errors().values()])
            AlertDialog.warning("Validation Error", f"Please fix the following errors:\n\n{error_messages}", self)
            self._submitting = False
            return

        data = {"code": self.code.text().strip(), "name": self.name.text().strip()}
        try:
            base_endpoint = get_endpoint("departments")
            if self._dept:
                resp = self._api_client.put(f"{base_endpoint}{self._dept['id']}/", data)
            else:
                resp = self._api_client.post(base_endpoint, data)
            if resp and isinstance(resp, dict) and (resp.get("success") or resp.get("id")):
                self.accept()
            else:
                err = resp.get("error", "Save failed") if isinstance(resp, dict) else "Save failed"
                AlertDialog.error("Error", str(err), self)
        except Exception as e:
            AlertDialog.error("Error", str(e), self)
        finally:
            self._submitting = False


class PositionDialog(EnterpriseDialog):
    def __init__(self, api_client=None, departments=None, parent=None):
        self._api_client = api_client
        self._departments = departments or []
        self._submitting = False
        super().__init__("Add Position", DialogType.CUSTOM, parent)
        self.setMinimumWidth(400)
        self.set_content(self._build_content())
        enter_shortcut = QShortcut(QKeySequence(Qt.Key_Return), self)
        enter_shortcut.activated.connect(self._save)
        self.code.setFocus()

    def _create_button_area(self):
        return None

    def _build_content(self):
        widget = QWidget()
        layout = QVBoxLayout(widget)
        layout.setContentsMargins(0, 0, 0, 0)

        section = FormSection("Position Details", primary=True)

        self.code = QLineEdit()
        self.code.setPlaceholderText("POS")
        self.code.setMinimumHeight(INPUT_HEIGHT_MD)

        self.title = QLineEdit()
        self.title.setPlaceholderText("Position title")
        self.title.setMinimumHeight(INPUT_HEIGHT_MD)

        self.dept_combo = QComboBox()
        self.dept_combo.setMinimumHeight(INPUT_HEIGHT_MD)
        for d in self._departments:
            self.dept_combo.addItem(d.get("name", ""), d.get("id"))

        section.add_field(self.code, "Code*:")
        section.add_field(self.title, "Title*:")
        section.add_field(self.dept_combo, "Department:")
        layout.addWidget(section)

        layout.addStretch()
        btn = QHBoxLayout()
        btn.setSpacing(SPACING_SM)
        btn.addStretch()
        cancel = EnterpriseButton("Cancel", variant=ButtonVariant.SECONDARY, size=ButtonSize.MEDIUM)
        cancel.clicked.connect(self.reject)
        save = EnterpriseButton("Save", variant=ButtonVariant.PRIMARY, size=ButtonSize.MEDIUM)
        save.clicked.connect(self._save)
        btn.addWidget(cancel)
        btn.addWidget(save)
        layout.addLayout(btn)
        return widget

    def _save(self):
        if self._submitting:
            return
        self._submitting = True

        validator = FormValidator()
        validator.validate_required("Code", self.code.text().strip(), "Code is required")
        validator.validate_required("Title", self.title.text().strip(), "Title is required")
        if validator.has_errors():
            error_messages = "\n".join([f"• {msg}" for msg in validator.get_errors().values()])
            AlertDialog.warning("Validation Error", f"Please fix the following errors:\n\n{error_messages}", self)
            self._submitting = False
            return

        data = {"code": self.code.text().strip(), "title": self.title.text().strip(), "department": self.dept_combo.currentData()}
        try:
            resp = self._api_client.post(get_endpoint("positions"), data)
            if resp and isinstance(resp, dict) and (resp.get("success") or resp.get("id")):
                self.accept()
            else:
                err = resp.get("error", "Save failed") if isinstance(resp, dict) else "Save failed"
                AlertDialog.error("Error", str(err), self)
        except Exception as e:
            AlertDialog.error("Error", str(e), self)
        finally:
            self._submitting = False
