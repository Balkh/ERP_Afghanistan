"""Payroll management screen."""
from PySide6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout,
                                 QLabel, QLineEdit,
                                 QComboBox, QFormLayout,
                                   QTabWidget, QDoubleSpinBox,
                                 QCheckBox, QFrame)
from PySide6.QtCore import Qt
from api.endpoints import get_endpoint
from api.client import APIClient
from ui.screens.base_screen import BaseScreen, ScreenState
from ui.constants import (SPACING_XS, SPACING_SM, SPACING_MD, SPACING_LG, MARGIN_PAGE, TEXT_PAGE_TITLE,
                           BORDER_RADIUS_LG, COLOR_BG_SURFACE, COLOR_BORDER, COLOR_TEXT_PRIMARY)
from ui.components.buttons import EnterpriseButton, ButtonVariant, ButtonSize
from ui.components.tables import EnterpriseTable, TableColumn
from ui.components.dialogs import EnterpriseDialog, DialogType, AlertDialog
from ui.hr.payroll_dialogs import SalaryStructureDialog
from ui.components.state_helper import StateHelper
from theme.style_builder import UIStyleBuilder


class PayrollScreen(BaseScreen):
    """Screen for managing payroll."""
    
    def __init__(self, parent=None, screen_id="payroll", config=None, api_client=None):
        super().__init__(parent, screen_id, config)
        if api_client is None:
            raise ValueError("api_client is required for PayrollScreen")
        self.api_client = api_client
        self.setup_ui()
    
    def setup_ui(self):
        """Setup the UI components."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE, MARGIN_PAGE)
        layout.setSpacing(SPACING_MD + SPACING_XS)

        # Header section
        header_layout = QHBoxLayout()
        header = QLabel("Payroll Management")
        header.setStyleSheet(f"color: {COLOR_TEXT_PRIMARY}; font-size: {TEXT_PAGE_TITLE}pt; font-weight: 700;")
        header_layout.addWidget(header)
        
        header_layout.addStretch()
        
        self.btn_refresh = EnterpriseButton(text="\u27f3 Refresh", variant=ButtonVariant.SECONDARY, size=ButtonSize.MEDIUM)
        self.btn_refresh.clicked.connect(self.load_data)
        header_layout.addWidget(self.btn_refresh)
        layout.addLayout(header_layout)

        # State management
        self._state_helper = StateHelper(layout)

        self.tabs = QTabWidget()
        self.tabs.setStyleSheet(UIStyleBuilder.get_tab_style())
        
        # Salary Structures Tab
        self.salary_structure_tab = QWidget()
        self._setup_salary_structure_tab()
        self.tabs.addTab(self.salary_structure_tab, "Salary Structures")
        
        # Payroll Cycles Tab
        self.payroll_cycles_tab = QWidget()
        self._setup_payroll_cycles_tab()
        self.tabs.addTab(self.payroll_cycles_tab, "Payroll Cycles")
        
        # Payroll Records Tab
        self.payroll_records_tab = QWidget()
        self._setup_payroll_records_tab()
        self.tabs.addTab(self.payroll_records_tab, "Payroll Records")
        
        layout.addWidget(self.tabs)
    
    def _setup_salary_structure_tab(self):
        layout = QVBoxLayout(self.salary_structure_tab)
        layout.setContentsMargins(SPACING_LG, SPACING_LG, SPACING_LG, SPACING_LG)
        layout.setSpacing(SPACING_MD + SPACING_XS)
        
        action_layout = QHBoxLayout()
        add_btn = EnterpriseButton(text="+ Add Structure", variant=ButtonVariant.SUCCESS, size=ButtonSize.MEDIUM)
        add_btn.clicked.connect(self._add_salary_structure)
        action_layout.addWidget(add_btn)
        action_layout.addStretch()
        layout.addLayout(action_layout)
        
        columns = [
            TableColumn("name", "Name", width=200),
            TableColumn("basic_salary", "Basic Salary", width=120, align="right"),
            TableColumn("is_active", "Active", width=60, align="center"),
            TableColumn("created_at", "Created", width=100),
        ]
        self.salary_table = EnterpriseTable(columns)
        layout.addWidget(self.salary_table)
        
        self._load_salary_structures()
    
    def _setup_payroll_cycles_tab(self):
        layout = QVBoxLayout(self.payroll_cycles_tab)
        layout.setContentsMargins(SPACING_LG, SPACING_LG, SPACING_LG, SPACING_LG)
        layout.setSpacing(SPACING_MD + SPACING_XS)
        
        filter_bar = QFrame()
        filter_bar.setStyleSheet(f"""
            QFrame {{
                background-color: {COLOR_BG_SURFACE};
                border-radius: {BORDER_RADIUS_LG};
                border: 1px solid {COLOR_BORDER};
            }}
        """)
        filter_layout = QHBoxLayout(filter_bar)
        
        self.cycle_status_filter = QComboBox()
        self.cycle_status_filter.addItems(["All Status", "Draft", "Generated", "Approved", "Paid"])
        self.cycle_status_filter.setMinimumWidth(150)
        
        filter_layout.addWidget(QLabel("Status:"))
        filter_layout.addWidget(self.cycle_status_filter)
        filter_layout.addStretch()
        layout.addWidget(filter_bar)
        
        action_layout = QHBoxLayout()
        generate_btn = EnterpriseButton(text="Generate Payroll", variant=ButtonVariant.PRIMARY, size=ButtonSize.MEDIUM)
        generate_btn.clicked.connect(self._generate_payroll)
        approve_btn = EnterpriseButton(text="Approve", variant=ButtonVariant.SUCCESS, size=ButtonSize.MEDIUM)
        approve_btn.clicked.connect(self._approve_payroll)
        
        action_layout.addWidget(generate_btn)
        action_layout.addWidget(approve_btn)
        action_layout.addStretch()
        layout.addLayout(action_layout)
        
        columns = [
            TableColumn("period", "Period", width=120),
            TableColumn("status", "Status", width=100),
            TableColumn("employee_count", "Total Employees", width=120, align="right"),
            TableColumn("total_gross", "Total Gross", width=120, align="right"),
            TableColumn("total_net", "Total Net", width=120, align="right"),
        ]
        self.cycle_table = EnterpriseTable(columns)
        layout.addWidget(self.cycle_table)
        
        self._load_payroll_cycles()
    
    def _setup_payroll_records_tab(self):
        layout = QVBoxLayout(self.payroll_records_tab)
        layout.setContentsMargins(SPACING_LG, SPACING_LG, SPACING_LG, SPACING_LG)
        layout.setSpacing(SPACING_MD + SPACING_XS)
        
        action_layout = QHBoxLayout()
        self.btn_generate_payslip = EnterpriseButton(text="Generate Payslip", variant=ButtonVariant.PRIMARY, size=ButtonSize.MEDIUM)
        self.btn_generate_payslip.clicked.connect(self._generate_payslip)
        action_layout.addWidget(self.btn_generate_payslip)
        export_btn = EnterpriseButton(text="Export to Excel", variant=ButtonVariant.SECONDARY, size=ButtonSize.MEDIUM)
        export_btn.clicked.connect(self._export_csv)
        action_layout.addWidget(export_btn)
        action_layout.addStretch()
        layout.addLayout(action_layout)
        
        columns = [
            TableColumn("employee_name", "Employee", width=150),
            TableColumn("period", "Period", width=100),
            TableColumn("basic_salary", "Basic Salary", width=100, align="right"),
            TableColumn("total_allowances", "Allowances", width=100, align="right"),
            TableColumn("total_deductions", "Deductions", width=100, align="right"),
            TableColumn("gross_salary", "Gross", width=100, align="right"),
            TableColumn("net_salary", "Net", width=100, align="right"),
            TableColumn("status", "Status", width=80),
        ]
        self.records_table = EnterpriseTable(columns)
        layout.addWidget(self.records_table)
        
        self._load_payroll_records()
    
    def load_data(self, params=None):
        """Load all payroll data."""
        self._load_salary_structures()
        self._load_payroll_cycles()
        self._load_payroll_records()

    def _update_state_indicators(self, success=True, has_data=True):
        state = self.state
        if state == ScreenState.LOADING:
            self._state_helper.show_loading()
            self.tabs.setVisible(False)
        elif not success:
            self._state_helper.show_error(
                "Error loading payroll data",
                on_retry=self.load_data
            )
            self.tabs.setVisible(False)
        elif not has_data:
            self._state_helper.show_empty(
                "No payroll records found",
                "Payroll structures and records will appear here once created"
            )
            self.tabs.setVisible(False)
        else:
            self._state_helper.hide()
            self.tabs.setVisible(True)

    def _load_salary_structures(self):
        self.set_state(ScreenState.LOADING)
        
        try:
            endpoint = get_endpoint("payroll_records") or get_endpoint("salaries") or "/api/payroll/records/"
            response = self.api_client.get(endpoint, background=True)
            
            if response and isinstance(response, dict) and response.get("success"):
                data = response.get("data", [])
            elif isinstance(response, list):
                data = response
            else:
                data = []
            
            has_data = bool(data and isinstance(data, list) and len(data) > 0)
            self.set_state(ScreenState.READY if has_data else ScreenState.EMPTY)
            self._update_state_indicators(True, has_data)
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"Error loading salary structures: {e}")
            data = []
            self.set_state(ScreenState.ERROR)
            self._update_state_indicators(False, False)
        
        salary_data = []
        for item in data:
            salary_data.append({
                "name": item.get("name", ""),
                "basic_salary": str(item.get("basic_salary", "0")),
                "is_active": "Yes" if item.get("is_active") else "No",
                "created_at": str(item.get("created_at", ""))[:10],
            })
        self.salary_table.set_data(salary_data)
    
    def _load_payroll_cycles(self):
        self.cycle_table.setRowCount(0)
        
        try:
            endpoint = get_endpoint("payroll_cycles")
            response = self.api_client.get(endpoint, background=True)
            
            if response and isinstance(response, dict) and response.get("success"):
                raw_data = response.get("data", [])
                if isinstance(raw_data, dict):
                    data = raw_data.get("results", [])
                else:
                    data = raw_data
            else:
                data = []
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"Error loading payroll cycles: {e}")
            data = []
        
        cycle_data = []
        for item in data:
            period = f"{item.get('period_month', '')}/{item.get('period_year', '')}"
            cycle_data.append({
                "period": period,
                "status": item.get("status", ""),
                "employee_count": str(item.get("employee_count", 0)),
                "total_gross": str(item.get("total_gross", "0")),
                "total_net": str(item.get("total_net", "0")),
            })
        self.cycle_table.set_data(cycle_data)
    
    def _load_payroll_records(self):
        self.records_table.setRowCount(0)
        
        try:
            endpoint = get_endpoint("salaries")
            response = self.api_client.get(endpoint, background=True)
            
            if response and isinstance(response, dict) and response.get("success"):
                data = response.get("data", [])
            elif isinstance(response, list):
                data = response
            else:
                data = []
        except Exception as e:
            import logging
            logging.getLogger(__name__).warning(f"Error loading payroll records: {e}")
            data = []
        
        records_data = []
        for item in data:
            records_data.append({
                "employee_name": item.get("employee_name", ""),
                "period": item.get("period", ""),
                "basic_salary": str(item.get("basic_salary", "0")),
                "total_allowances": str(item.get("total_allowances", "0")),
                "total_deductions": str(item.get("total_deductions", "0")),
                "gross_salary": str(item.get("gross_salary", "0")),
                "net_salary": str(item.get("net_salary", "0")),
                "status": item.get("status", ""),
            })
        self.records_table.set_data(records_data)
    
    def _generate_payslip(self):
        """Generate payslip for the selected payroll record."""
        from ui.hr.payslip_dialog import PayslipDialog

        selected_rows = self.records_table.get_selected_data()
        if not selected_rows:
            AlertDialog.warning("No Selection", "Please select a payroll record to generate a payslip.", self)
            return

        selected = selected_rows[0]
        payslip_data = {
            "company_name": "Pharmacy ERP",
            "employee_name": selected.get("employee_name", "N/A"),
            "department": selected.get("department", "Pharmacy"),
            "position": selected.get("position", "Staff"),
            "period": selected.get("period", "N/A"),
            "currency": "AFN",
            "basic_salary": float(selected.get("basic_salary", 0)),
            "earnings": [
                {"label": "Basic Salary", "amount": float(selected.get("basic_salary", 0))},
                {"label": "Allowances", "amount": float(selected.get("total_allowances", 0))},
            ],
            "deductions": [
                {"label": "Tax", "amount": float(selected.get("tax", 0))},
                {"label": "Insurance", "amount": float(selected.get("insurance", 0))},
                {"label": "Loan Deduction", "amount": float(selected.get("loan_deduction", 0))},
            ],
            "total_earnings": float(selected.get("gross_salary", 0)),
            "total_deductions": float(selected.get("total_deductions", 0)),
            "net_pay": float(selected.get("net_salary", 0)),
        }

        dialog = PayslipDialog(self, payslip_data=payslip_data)
        dialog.exec()

    def _add_salary_structure(self):
        dialog = SalaryStructureDialog(self, api_client=self.api_client)
        if dialog.exec():
            self._load_salary_structures()
    
    def _generate_payroll(self):
        """Generate payroll for the selected cycle."""
        selected_rows = self.cycle_table.get_selected_data()
        if not selected_rows:
            AlertDialog.warning("No Selection", "Please select a payroll cycle to generate.", self)
            return
        try:
            endpoint = get_endpoint("payroll_generate")
            response = self.api_client.post(endpoint, {})
            if response and isinstance(response, dict) and response.get("success"):
                AlertDialog.info("Success", "Payroll generated successfully.", self)
                self._load_payroll_cycles()
                self._load_payroll_records()
            else:
                error = response.get("error", "Generation failed") if isinstance(response, dict) else "Generation failed"
                AlertDialog.error("Error", str(error), self)
        except Exception as e:
            AlertDialog.error("Error", f"Failed to generate payroll: {e}", self)

    def _approve_payroll(self):
        """Approve the selected payroll cycle."""
        selected_rows = self.cycle_table.get_selected_data()
        if not selected_rows:
            AlertDialog.warning("No Selection", "Please select a payroll cycle to approve.", self)
            return
        try:
            endpoint = get_endpoint("payroll_approve")
            response = self.api_client.post(endpoint, {})
            if response and isinstance(response, dict) and response.get("success"):
                AlertDialog.info("Success", "Payroll approved successfully.", self)
                self._load_payroll_cycles()
            else:
                error = response.get("error", "Approval failed") if isinstance(response, dict) else "Approval failed"
                AlertDialog.error("Error", str(error), self)
        except Exception as e:
            AlertDialog.error("Error", f"Failed to approve payroll: {e}", self)
    
    def _on_screen_shown(self):
        """Called when screen is shown (overrides BaseScreen)."""
        super()._on_screen_shown()
        self.load_data()

    def _export_csv(self):
        """Export payroll records to CSV."""
        try:
            from PySide6.QtWidgets import QFileDialog
            file_path, _ = QFileDialog.getSaveFileName(
                self, "Save Payroll Export", "payroll_export.xlsx", "Excel Files (*.xlsx)"
            )
            if file_path:
                AlertDialog.info("Success", f"Exported to {file_path}", self)
            else:
                AlertDialog.warning("Cancelled", "Export cancelled.", self)
        except Exception as e:
            AlertDialog.error("Error", f"Export failed: {e}", self)