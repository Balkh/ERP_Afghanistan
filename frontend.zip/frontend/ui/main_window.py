import sys
import os
import time
from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QFrame, QLabel, QStackedWidget, QStatusBar, QApplication, QSizePolicy
from PySide6.QtCore import Qt, QTimer, QThread, Signal, QObject
from PySide6.QtGui import QFont, QAction, QKeySequence

from ui.licensing.license_manager_dialog import LicenseManagerDialog
from ui.sidebar import Sidebar
from ui.dashboard import Dashboard
from security.auth_manager import AuthManager
from ui.role_renderer import RoleRenderer
from ui.components.notifications import show_warning
from ui.components.dialogs import AlertDialog, ConfirmDialog
from ui.components.loading_spinner import LoadingOverlay
from ui.components.navigation_header import NavigationHeader
from ui.components.search_palette import SearchPalette

from ui.navigation_history import NavigationHistory
from theme.theme_engine import ThemeEngine
from ui.utils.lazy_loader import LazyScreenManager
from utils.logger import get_logger, set_active_screen, get_active_screen, safe_execute, SafeBoundary, capture_health_snapshot, generate_correlation_id, record_screen_load, record_error, emit_event
from ui.constants import (
    SPACING_NONE, SPACING_XS, SPACING_SM, SPACING_MD, SPACING_LG, SPACING_XL, MARGIN_PAGE,
    SPACING_6, BORDER_RADIUS_MD, BORDER_RADIUS_SM, BORDER_RADIUS_LG, TEXT_BODY, TEXT_LABEL,
    TEXT_PAGE_TITLE, TEXT_TABLE, FONT_NAME_PRIMARY, COLOR_TEXT_MUTED, COLOR_BG_MAIN,
    COLOR_BG_SURFACE, COLOR_BG_ELEVATED, COLOR_BORDER, COLOR_BORDER_LIGHT, COLOR_BORDER_FOCUS,
    COLOR_TEXT_PRIMARY, COLOR_TEXT_ON_PRIMARY, COLOR_TEXT_SECONDARY, COLOR_PRIMARY,
    COLOR_PRIMARY_HOVER, COLOR_SUCCESS, COLOR_WARNING, COLOR_DANGER, COLOR_STATUS_VALID
)
from ui.role_manager import UserRole

log = get_logger('ui')
import ui.constants as _constants

from runtime.timer_registry import shutdown_all_timers


class MainWindow(QMainWindow):
    def __init__(self, license_validator=None, user_data: dict = None, api_client=None, auth_manager=None):
        super().__init__()
        self.setWindowTitle("Pharmacy ERP")
        self.setGeometry(100, 100, 1400, 900)
        self.setMinimumSize(1200, 800)

        # Store license validator
        self.license_validator = license_validator

        # Initialize AuthManager (primary auth state source)
        self.auth_manager = auth_manager or AuthManager(api_client)

        # Sync user_data into auth_manager if provided from login
        if user_data:
            self.auth_manager._user_data = user_data
            self.auth_manager._roles = user_data.get("roles", [])
            self.auth_manager._ui_scopes = user_data.get("ui_scopes", self.auth_manager._ui_scopes)
            self.auth_manager._is_authenticated = True

        # Store user_data for backward compatibility
        self.user_data = self.auth_manager.user or user_data or {}
        self.user_role = self._determine_role()

        # Initialize API client
        self.api_client = api_client if api_client else self.auth_manager.api_client

        # Initialize RoleRenderer (sidebar set after _build_ui)
        self.role_renderer = RoleRenderer(
            auth_manager=self.auth_manager,
            sidebar=None,
            main_window=self,
        )

        # Initialize unified theme engine (single source of truth)
        self.theme_engine = ThemeEngine.instance()
        self.theme_engine.theme_changed.connect(self.on_theme_changed)

        # Navigation System (Phase 4-5)
        self.navigation_history = NavigationHistory()
        self._disable_history = False

        # Recent Items & Pinned Items System (Sprint 3.4)
        from ui.recent_items_storage import RecentItemsStorage
        from ui.pinned_items_manager import PinnedItemsManager
        from ui.navigation_integration import NavigationIntegration

        # Use authenticated user ID instead of hardcoded default
        user_id = "default"
        if self.auth_manager and hasattr(self.auth_manager, 'user') and self.auth_manager.user:
            # Extract user ID from authenticated user
            user = self.auth_manager.user
            user_id = user.get('id', user.get('user_id', 'default'))
        elif self.user_data:
            # Fallback to user_data if available
            user_id = self.user_data.get('id', self.user_data.get('user_id', 'default'))
        
        # Store user_id for sidebar integration
        self.user_id = user_id

        self.recent_items_storage = RecentItemsStorage(user_id=user_id, max_items=10)
        self.pinned_items_manager = PinnedItemsManager(self.recent_items_storage)
        self.navigation_integration = NavigationIntegration(self.navigation_history, self.recent_items_storage)

        # Connect license validator signals
        if self.license_validator:
            self.license_validator.license_valid.connect(self.on_license_validation_changed)
            self.license_validator.license_status_changed.connect(self.on_license_status_changed)

        log.debug(f"User role: {self.user_role}",
                  extra={'extra_fields': {'tags': ['auth', 'startup']}})

        # Build the UI
        self._setup_status_bar()
        self._build_ui()

        # Defer non-critical network work until after first paint
        QTimer.singleShot(3000, self._load_company_settings)
        QTimer.singleShot(5000, self._check_startup_health)

        try:
            hs = capture_health_snapshot()
            log.debug(f"MainWindow health snapshot: {hs}",
                      extra={'extra_fields': {'tags': ['ui', 'startup', 'diagnostic']}})
        except Exception as e:
            log.error(f"Failed to capture health snapshot: {e}",
                      extra={'extra_fields': {'tags': ['ui', 'startup', 'diagnostic']}})

    def _setup_status_bar(self):
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)

        # Status bar components setup (simplified for brevity)
        self.connection_status_label = QLabel()
        self.status_bar.addWidget(self.connection_status_label)

    def _check_startup_health(self):
        pass

    def _on_startup_health_result(self, label: str, color: str, message: str):
        if hasattr(self, 'health_label'):
            self.health_label.setText(label)
            self.health_label.setStyleSheet(f"color: {color};")

    def _update_status_bar_time(self):
        from datetime import datetime
        if hasattr(self, 'time_label'):
            self.time_label.setText(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

    def _load_company_settings(self):
        pass

    def _on_company_settings_loaded(self, company_name: str):
        if company_name:
            try:
                self.setWindowTitle(f"{company_name} - Pharmacy ERP")
            except RuntimeError:
                pass

    def _determine_role(self):
        try:
            from ui.role_manager import get_role_from_user_data
            role = get_role_from_user_data(self.user_data)
            return role
        except Exception as e:
            log.error(f"Failed to determine user role: {e}",
                      extra={'extra_fields': {'tags': ['ui', 'auth', 'startup']}})
            return UserRole.VIEWER

    def _on_ui_scopes_changed(self, ui_scopes: dict) -> None:
        if hasattr(self, 'role_renderer'):
            self.role_renderer.apply_scopes()
        if hasattr(self, 'sidebar'):
            self._apply_sidebar_scopes(ui_scopes)
        self._update_status_bar_user_info()

    def _apply_sidebar_scopes(self, ui_scopes: dict) -> None:
        visible_modules = set(ui_scopes.get("sidebar", []))
        group_items_map = {
            "inventory": {"inventory"},
            "sales": {"sales"},
            "purchases": {"purchases"},
            "returns": {"returns"},
            "accounting": {"accounting"},
            "reports": {"reports"},
            "finance": {"finance"},
            "hr": {"hr"},
            "system": {"system"},
        }

        for group_name, group_widget in self.sidebar._group_widgets.items():
            group_modules = group_items_map.get(group_name, set())
            any_visible = any(mod in visible_modules for mod in group_modules)
            if group_widget:
                group_widget.setVisible(any_visible)

    def _update_status_bar_user_info(self) -> None:
        user = self.auth_manager.user or self.user_data
        user_name = user.get('username', user.get('full_name', 'User'))
        roles = self.auth_manager.roles or [self.user_role.name]
        role_display = roles[0] if roles else self.user_role.name
        if hasattr(self, 'user_label'):
            self.user_label.setText(f"👤 User: {user_name} ({role_display})")

    def _build_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout()
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(SPACING_NONE)
        central_widget.setLayout(main_layout)

        # Pass user_id to sidebar to ensure consistent storage
        self.sidebar = Sidebar(role=self.user_role, user_id=self.user_id, max_items=10)
        main_layout.addWidget(self.sidebar)

        content_frame = QFrame()
        content_frame.setFrameStyle(QFrame.Shape.NoFrame)
        main_layout.addWidget(content_frame, 1)

        content_layout = QVBoxLayout(content_frame)
        content_layout.setContentsMargins(MARGIN_PAGE, SPACING_SM, MARGIN_PAGE, SPACING_MD)
        content_layout.setSpacing(SPACING_MD + SPACING_XS)

        self.header = QLabel("Pharmacy ERP Dashboard")
        self.header.setFont(QFont(FONT_NAME_PRIMARY, TEXT_PAGE_TITLE, QFont.Weight.Bold))
        self.header.setAlignment(Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter)
        self.header.setFixedHeight(60)
        content_layout.addWidget(self.header)

        self.nav_header = NavigationHeader()
        self.nav_header.setVisible(False)
        self.nav_header.back_clicked.connect(self._go_back)
        self.nav_header.home_clicked.connect(self._go_home)
        self.nav_header.close_clicked.connect(self._close_screen)
        self.nav_header.breadcrumb_clicked.connect(self._on_breadcrumb_clicked)
        content_layout.addWidget(self.nav_header)

        self.pages = QStackedWidget()
        self.pages.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        content_layout.addWidget(self.pages)

        self.dashboard = Dashboard(role=self.user_role, api_client=self.api_client)
        self.pages.addWidget(self.dashboard)

        self._lazy_screens = LazyScreenManager(self.pages, self.api_client)

        from ui.screen_registry import register_all_screens
        register_all_screens(self._lazy_screens, self)

        self.sidebar.page_changed.connect(self.change_page)
        self.sidebar.set_active_item(0)

    def change_page(self, index, page_title):
        page_to_module = {
            0: "dashboard", 1: "inventory", 2: "inventory", 3: "inventory", 4: "inventory",
            5: "sales", 6: "purchases", 7: "sales", 8: "purchases",
            9: "returns", 10: "accounting", 11: "accounting", 12: "accounting", 58: "accounting", 59: "accounting",
            13: "reports", 14: "reports", 15: "reports", 16: "reports", 17: "reports",
            18: "finance", 19: "finance", 20: "finance", 21: "finance", 22: "finance", 34: "finance",
            37: "sales", 60: "finance", 61: "finance", 62: "finance", 63: "finance", 64: "finance", 65: "finance",
            23: "hr", 24: "hr", 25: "hr", 26: "hr", 67: "hr",
            49: "hr", 50: "hr", 51: "hr", 52: "hr",
            53: "hr", 54: "hr", 55: "hr", 56: "hr",
            27: "system", 28: "system", 29: "system", 30: "system", 31: "system",
            32: "system", 33: "system", 35: "system", 36: "system",
            38: "system", 39: "system", 40: "system", 47: "system", 48: "system", 66: "system",
        }
        module = page_to_module.get(index, "dashboard")
        if not self.auth_manager.has_access(module):
            show_warning(f"Access denied: you don't have permission to view {page_title.strip()}")
            return

        if not self._disable_history:
            current = self.pages.currentIndex()
            if current != index:
                self.navigation_history.push(current, page_title.strip())
                
        self.recent_items_storage.add_screen(index, page_title.strip(), page_title.strip().lower().replace(" ", "_"))
        if hasattr(self, 'navigation_integration'):
            self.navigation_integration.handle_navigation_change(index, page_title.strip())

        if index != 0 and hasattr(self, '_lazy_screens'):
            screen = self._lazy_screens.load(index)
            if screen and hasattr(screen, 'load_products'):
                screen.load_products()

        self.header.setText(page_title.strip())
        self.header.setVisible(False)
        self.pages.setCurrentIndex(index)
        self.sidebar.set_active_item(index)
        self._update_nav_header(index, page_title)

    def _update_nav_header(self, index: int, page_title: str):
        show_nav = (index != 0)
        self.nav_header.setVisible(show_nav)
        self.header.setVisible(not show_nav)

    def _build_breadcrumb(self, index: int, page_title: str) -> list:
        page_map = {
            0: "Home", 1: "Products", 2: "Categories", 3: "Warehouses", 4: "Batches",
            5: "Sales Invoice", 6: "Purchase Invoice", 7: "Customers", 8: "Suppliers",
            9: "Returns", 10: "Chart of Accounts", 11: "Journal Entries", 12: "Account Ledger",
            13: "Trial Balance", 14: "Profit & Loss", 15: "Balance Sheet",
            16: "AR Ageing", 17: "AP Ageing", 18: "Payments", 19: "Budgeting",
            20: "Tax", 21: "Cost Centers", 22: "Cash Flow", 23: "Employees",
            24: "Attendance", 25: "Leave", 26: "Payroll", 27: "Backup",
            28: "Settings", 29: "Fixed Assets", 30: "Audit", 31: "User Management",
            32: "Intelligence Hub", 33: "Invoice Templates", 34: "Expenses",
            35: "Entities", 36: "Licensing", 37: "POS Terminal", 38: "Control Center",
            39: "Observability", 40: "Analytics", 47: "Decision Workspace",
            48: "Role Management", 49: "Employee Summary", 50: "Attendance Report",
            51: "Leave Report", 52: "Overtime Report", 53: "Payroll Summary",
            54: "Payroll Trend", 55: "Payroll Dept Cost", 56: "Payroll Employee History",
            57: "Reconciliation", 58: "Financial Integrity", 59: "Financial Audit",
            60: "Customer Payments", 61: "Supplier Payments", 62: "Allocation Explorer",
            63: "Returns Explainability", 64: "Journal Reversals", 65: "Operations Console",
            66: "Company Profile",
        }
        if index in [1, 2, 3, 4]:
            return ["Home", "Inventory", page_map.get(index, page_title)]
        elif index in [5, 7, 37]:
            return ["Home", "Sales", page_map.get(index, page_title)]
        elif index in [6, 8]:
            return ["Home", "Purchases", page_map.get(index, page_title)]
        elif index in [10, 11, 12, 58, 59]:
            return ["Home", "Accounting", page_map.get(index, page_title)]
        elif index in [13, 14, 15, 16, 17]:
            return ["Home", "Reports", page_map.get(index, page_title)]
        elif index in [18, 19, 20, 21, 22, 34, 60, 61, 62, 63, 64, 65]:
            return ["Home", "Finance", page_map.get(index, page_title)]
        elif index in [23, 24, 25, 26, 49, 50, 51, 52, 53, 54, 55, 56]:
            return ["Home", "HR", page_map.get(index, page_title)]
        elif index in [27, 28, 29, 30, 31, 32, 33, 35, 36, 38, 39, 40, 47, 48, 66]:
            return ["Home", "System", page_map.get(index, page_title)]
        elif index in [9, 57]:
            return ["Home", "Returns", page_map.get(index, page_title)]
        else:
            return ["Home", page_map.get(index, page_title)]

    def _go_back(self):
        with SafeBoundary(log_context="go_back", tags=['ui', 'navigation']):
            self._do_go_back()

    def _do_go_back(self):
        if self.navigation_history:
            prev_index, prev_title = self.navigation_history.pop()
            self._disable_history = True
            self.pages.setCurrentIndex(prev_index)
            self.header.setText(prev_title)
            self.sidebar.set_active_item(prev_index)
            self._disable_history = False
            current_idx = self.pages.currentIndex()
            self._update_nav_header(current_idx, prev_title)

    def _go_home(self):
        with SafeBoundary(log_context="go_home", tags=['ui', 'navigation']):
            self._do_go_home()

    def _do_go_home(self):
        self._disable_history = True
        self.pages.setCurrentIndex(0)
        self.header.setText("Pharmacy ERP Dashboard")
        self.sidebar.set_active_item(0)
        self._disable_history = False
        self._update_nav_header(0, "Pharmacy ERP Dashboard")

    def create_menu_bar(self):
        menubar = self.menuBar()

        file_menu = menubar.addMenu('File')
        refresh_action = QAction('Refresh', self)
        refresh_action.setStatusTip('Refresh current view')
        refresh_action.triggered.connect(self.refresh_current_view)
        file_menu.addAction(refresh_action)

        file_menu.addSeparator()
        logout_action = QAction('Logout', self)
        logout_action.setStatusTip('Logout and return to login')
        logout_action.triggered.connect(self.logout)
        file_menu.addAction(logout_action)

    def logout(self):
        from runtime.ux_telemetry import record_exit_point
        record_exit_point("logout")
        reply = ConfirmDialog.confirm(
            "Logout",
            "Are you sure you want to logout?",
            self,
        )

        if reply:
            username = self.auth_manager.user.get('username', 'unknown') if self.auth_manager.user else 'unknown'
            _cid = generate_correlation_id("auth")
            try:
                hs = capture_health_snapshot()
                log.info(f"User logout: {username} | snapshot: {hs}",
                          extra={'extra_fields': {'tags': ['auth', 'logout', 'diagnostic']}})
            except Exception:
                log.info(f"User logout: {username}",
                          extra={'extra_fields': {'tags': ['auth', 'logout']}})
            emit_event('auth_event', module='main_window', action='logout',
                      metadata={'username': username, 'screen': get_active_screen()},
                      correlation_id=_cid)

            self.auth_manager._clear_session()
            self.close()

    def show_license_manager(self):
        dialog = LicenseManagerDialog(self)
        dialog.exec()

    def show_about(self):
        AlertDialog.info(
            "About Pharmacy ERP",
            "Pharmacy ERP v1.0.0\n\n"
            "A comprehensive enterprise resource planning system\n"
            "for pharmaceutical distribution management.\n\n"
            "© 2026 Pharmacy ERP Solutions. All rights reserved.",
            self,
        )

    def navigate_to(self, page_id):
        with SafeBoundary(log_context="navigate_to", tags=['ui', 'navigation']):
            self._do_navigate(page_id)

    def _do_navigate(self, page_id):
        if not self.auth_manager.has_access(page_id) and page_id not in ("dashboard", "settings"):
            show_warning(f"Access denied: you don't have permission to view {page_id}")
            return

        page_map = {
            "dashboard": 0,
            "products": 1,
            "categories": 2,
            "warehouses": 3,
            "batches": 4,
            "sales_invoice": 5,
            "purchase_invoice": 6,
            "customers": 7,
            "suppliers": 8,
            "returns": 9,
            "chart_of_accounts": 10,
            "journal_entries": 11,
            "account_ledger": 12,
            "trial_balance": 13,
            "profit_loss": 14,
            "balance_sheet": 15,
            "ar_ageing": 16,
            "ap_ageing": 17,
            "payments": 18,
            "budgeting": 19,
            "tax": 20,
            "cost_centers": 21,
            "cashflow": 22,
            "employees": 23,
            "attendance": 24,
            "leave": 25,
            "payroll": 26,
            "backup": 27,
            "settings": 28,
            "fixed_assets": 29,
            "audit": 30,
            "user_management": 31,
            "intelligence_hub": 32,
            "invoice_templates": 33,
            "expenses": 34,
            "entities": 35,
            "licensing": 36,
            "pos": 37,
            "control_center": 38,
            "observability": 39,
            "analytics": 40,
            "decision_workspace": 47,
            "role_management": 48,
            "employee_summary": 49,
            "attendance_report": 50,
            "leave_report": 51,
            "overtime_report": 52,
            "payroll_summary": 53,
            "payroll_trend": 54,
            "payroll_dept_cost": 55,
            "payroll_emp_history": 56,
            "reconciliation": 57,
            "financial_integrity": 58,
            "financial_audit": 59,
            "customer_payments": 60,
            "supplier_payments": 61,
            "allocation_explorer": 62,
            "returns_explainability": 63,
            "journal_reversals": 64,
            "operations_console": 65,
            "company_profile": 66,
        }
        if page_id in page_map:
            index = page_map[page_id]
            if index != 0 and hasattr(self, '_lazy_screens'):
                self._lazy_screens.load(index)
            current = self.pages.currentIndex()
            if current != index and not self._disable_history:
                title = page_id.replace('_', ' ').title()
                self.navigation_history.push(current, title)
            self.pages.setCurrentIndex(index)
            self.sidebar.set_active_item(index)
            self._update_nav_header(index, page_id.replace('_', ' ').title())
            self.status_bar.showMessage(f"Navigated to {page_id.replace('_', ' ').title()}", 2000)

    def on_license_validation_changed(self, is_valid: bool, message: str):
        if not hasattr(self, 'license_status_label'):
            return

        if is_valid:
            self.license_status_label.setText(f"License: Valid ({message})")
            self.license_status_label.setStyleSheet(f"font-size: {TEXT_LABEL}pt; color: {COLOR_SUCCESS}; margin-left: {SPACING_MD}px; font-weight: 500;")
        else:
            self.license_status_label.setText(f"License: Invalid ({message})")
            self.license_status_label.setStyleSheet(f"font-size: {TEXT_LABEL}pt; color: {COLOR_DANGER}; margin-left: {SPACING_MD}px; font-weight: 500;")

            if not is_valid and "too many times" in message:
                AlertDialog.error(
                    "License Validation Failed",
                    f"The application license has failed validation too many times:\n\n{message}\n\n"
                    "The application will now exit.",
                    self,
                )
                self.close()

    def on_license_status_changed(self, message: str):
        self.status_bar.showMessage(message, 5000)

    def toggle_theme(self):
        engine = ThemeEngine.instance()
        engine.toggle()

    def on_theme_changed(self, theme_name):
        _cid = generate_correlation_id("theme")
        engine = ThemeEngine.instance()
        if engine.current_theme() != theme_name:
            engine.apply_theme(theme_name)
        self._refresh_window_styles()
        self.status_bar.showMessage(f"Switched to {theme_name} mode", 2000)
        hs = {}
        try:
            hs = capture_health_snapshot()
            log.info(f"Theme switched to {theme_name} | snapshot: {hs}",
                      extra={'extra_fields': {'tags': ['ui', 'theme', 'diagnostic']}})
        except Exception:
            log.info(f"Theme switched to {theme_name}",
                      extra={'extra_fields': {'tags': ['ui', 'theme']}})
        emit_event('ui_action', module='main_window',
                   action=f'theme_switch:{theme_name}',
                   metadata={'snapshot': hs},
                   correlation_id=_cid)

    def _refresh_window_styles(self):
        with SafeBoundary(log_context="refresh_window_styles", tags=['ui', 'theme']):
            self._do_refresh_window_styles()

    def _do_refresh_window_styles(self):
        if not hasattr(self, 'pages'):
            return
        C = _constants
        content_frame = self.sidebar.parent() if hasattr(self, 'sidebar') else None
        for child in self.findChildren(QFrame):
            if child.parent() is self.centralWidget():
                content_frame = child
                break
        if content_frame:
            content_frame.setStyleSheet(f"""
                QFrame {{
                    background-color: {C.COLOR_BG_MAIN};
                }}
                QLabel {{
                    color: {C.COLOR_TEXT_PRIMARY};
                }}
                QGroupBox {{
                    color: {C.COLOR_TEXT_PRIMARY};
                    font-weight: bold;
                    border: 1px solid {C.COLOR_BORDER};
                    border-radius: {C.BORDER_RADIUS_LG}px;
                    margin-top: {C.SPACING_SM}px;
                    padding-top: {C.SPACING_SM}px;
                }}
                QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
                    background-color: {C.COLOR_BG_SURFACE};
                    color: {C.COLOR_TEXT_PRIMARY};
                    border: 1px solid {C.COLOR_BORDER};
                    border-radius: {C.BORDER_RADIUS_MD}px;
                    padding: {C.SPACING_SM}px;
                }}
            """)
        self._refresh_status_bar()

    def _refresh_status_bar(self):
        C = _constants
        for attr, ss in [
            ('user_label', f"color: {C.COLOR_TEXT_SECONDARY}; margin-right: {C.SPACING_LG}px;"),
            ('conn_label', f"color: {C.COLOR_STATUS_VALID}; margin-right: {C.SPACING_LG}px; font-weight: bold;"),
            ('time_label', f"color: {C.COLOR_TEXT_SECONDARY}; margin-right: {C.SPACING_LG}px;"),
            ('device_id_label', f"font-size: {C.TEXT_LABEL}pt; color: {C.COLOR_TEXT_MUTED};"),
            ('license_status_label', f"font-size: {C.TEXT_LABEL}pt; color: {C.COLOR_TEXT_MUTED}; margin-left: {C.SPACING_MD}px;"),
            ('connection_status_label', f"font-size: {C.TEXT_LABEL}pt; color: {C.COLOR_TEXT_MUTED}; margin-left: {C.SPACING_MD}px;"),
        ]:
            widget = getattr(self, attr, None)
            if widget is not None:
                try:
                    widget.setStyleSheet(ss)
                except RuntimeError:
                    pass
        if hasattr(self, 'header'):
            self.header.setStyleSheet(f"""
                QLabel {{
                    color: {COLOR_TEXT_PRIMARY};
                    padding-left: {SPACING_SM}px;
                }}
            """)

    def _get_breadcrumb_pages(self, index: int) -> list:
        page_map = {
            0: "Home", 1: "Products", 2: "Categories", 3: "Warehouses", 4: "Batches",
            5: "Sales Invoice", 6: "Purchase Invoice", 7: "Customers", 8: "Suppliers",
            9: "Returns", 10: "Chart of Accounts", 11: "Journal Entries", 12: "Account Ledger",
            13: "Trial Balance", 14: "Profit & Loss", 15: "Balance Sheet",
            16: "AR Ageing", 17: "AP Ageing", 18: "Payments", 19: "Budgeting",
            20: "Tax", 21: "Cost Centers", 22: "Cash Flow", 23: "Employees",
            24: "Attendance", 25: "Leave", 26: "Payroll", 27: "Backup",
            28: "Settings", 29: "Fixed Assets", 30: "Audit", 31: "User Management",
            32: "Intelligence Hub", 33: "Invoice Templates", 34: "Expenses",
            35: "Entities", 36: "Licensing", 37: "POS Terminal", 38: "Control Center",
            39: "Observability", 40: "Analytics", 47: "Decision Workspace",
            48: "Role Management", 49: "Employee Summary", 50: "Attendance Report",
            51: "Leave Report", 52: "Overtime Report", 53: "Payroll Summary",
            54: "Payroll Trend", 55: "Payroll Dept Cost", 56: "Payroll Employee History",
            57: "Reconciliation", 58: "Financial Integrity", 59: "Financial Audit",
            60: "Customer Payments", 61: "Supplier Payments", 62: "Allocation Explorer",
            63: "Returns Explainability", 64: "Journal Reversals", 65: "Operations Console",
            66: "Company Profile",
        }
        if index in [1, 2, 3, 4]:
            return [None, 3, index]
        elif index in [5, 7, 37]:
            return [None, 5, index]
        elif index in [6, 8]:
            return [None, 6, index]
        elif index in [10, 11, 12, 58, 59]:
            return [None, 10, index]
        elif index in [13, 14, 15, 16, 17]:
            return [None, 13, index]
        elif index in [18, 19, 20, 21, 22, 34, 60, 61, 62, 63, 64, 65]:
            return [None, 18, index]
        elif index in [23, 24, 25, 26, 49, 50, 51, 52, 53, 54, 55, 56]:
            return [None, 23, index]
        elif index in [27, 28, 29, 30, 31, 32, 33, 35, 36, 38, 39, 40, 47, 48, 66]:
            return [None, 27, index]
        elif index in [9, 57]:
            return [None, 9, index]
        else:
            return [None, index]

    def _on_breadcrumb_clicked(self, breadcrumb_index: int):
        index = self.pages.currentIndex()
        breadcrumb_pages = self._get_breadcrumb_pages(index)
        if breadcrumb_index < len(breadcrumb_pages):
            target = breadcrumb_pages[breadcrumb_index]
            if target is not None and target != index:
                title = self._build_breadcrumb(index, self.header.text())[breadcrumb_index] if hasattr(self, '_last_page_title') else "Home"
                self.sidebar.page_changed.emit(target, title)

    def _close_screen(self):
        if self.navigation_history:
            self._go_back()
        else:
            self._go_home()

    def show_preferences(self):
        AlertDialog.info("Preferences", "Preferences panel would open here.", self)

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
        else:
            self.showFullScreen()

    def new_product(self):
        AlertDialog.info("New Product", "Navigate to Products and click Add New.", self)
        self.navigate_to("products")

    def show_stock_alerts(self):
        AlertDialog.info("Stock Alerts", "Showing low stock items...", self)

    def open_calculator(self):
        import subprocess
        try:
            subprocess.Popen('calc.exe')
        except Exception:
            AlertDialog.warning("Error", "Could not open calculator.", self)

    def open_calendar(self):
        import subprocess
        try:
            subprocess.Popen('outlook.exe')
        except Exception:
            AlertDialog.info("Calendar", "Calendar integration not available.", self)

    def refresh_current_view(self):
        with SafeBoundary(log_context="refresh_current_view", tags=['ui', 'navigation']):
            self._do_refresh_current_view()

    def _do_refresh_current_view(self):
        index = self.pages.currentIndex()
        if index != 0 and hasattr(self, '_lazy_screens'):
            screen = self._lazy_screens.get(index)
            if screen and hasattr(screen, 'refresh_data'):
                screen.refresh_data()
        self.status_bar.showMessage("Refreshed", 2000)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, 'loading_overlay'):
            self.loading_overlay.setGeometry(0, 0, self.width(), self.height())

    def closeEvent(self, event):
        from runtime.ux_telemetry import record_exit_point, shutdown_telemetry
        record_exit_point("close")
        if hasattr(self, 'status_timer') and self.status_timer is not None:
            self.status_timer.stop()
        if hasattr(self, 'connection_timer') and self.connection_timer is not None:
            self.connection_timer.stop()
        shutdown_telemetry()
        shutdown_all_timers()
        super().closeEvent(event)

    def keyPressEvent(self, event):
        if event.modifiers() == Qt.AltModifier and event.key() == Qt.Key_Left:
            self._go_back()
            return

        if event.modifiers() == Qt.AltModifier and event.key() == Qt.Key_Home:
            self._go_home()
            return

        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_Backspace:
            if self.pages.currentIndex() != 0:
                self._close_screen()
            return

        if event.modifiers() == Qt.ControlModifier and event.key() == Qt.Key_Home:
            self._go_home()
            return

        if event.key() == Qt.Key_F5:
            self.refresh_current_view()
            return

        if event.key() == Qt.Key_Escape:
            if hasattr(self, '_search_palette') and self._search_palette.isVisible():
                self._search_palette.hide()
                return
            if self.pages.currentIndex() != 0:
                self._close_screen()
            return

        super().keyPressEvent(event)


# Background worker classes (simplified for brevity)
class _StartupHealthWorker(QObject):
    def __init__(self, api_client):
        super().__init__()
        self._api_client = api_client
        self.result = Signal(str, str, str)
        self.finished = Signal()

    def run(self):
        pass

class _CompanySettingsWorker(QObject):
    def __init__(self, api_client):
        super().__init__()
        self._api_client = api_client
        self.result = Signal(str)
        self.finished = Signal()

    def run(self):
        pass

    
