"""Helpers for JournalEntryScreen — extracted from journal_entry_screen.py."""
from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout, QLabel,
                               QComboBox, QLineEdit, QDateEdit,
                               QGroupBox)
from api.endpoints import get_endpoint, extract_list
from utils.format import safe_float
from ui.constants import (SPACING_XS, SPACING_SM, SPACING_MD, SPACING_XL,
                           TEXT_LABEL, BORDER_RADIUS_MD, BORDER_RADIUS_LG,
                           COLOR_BG_SURFACE, COLOR_BG_ELEVATED, COLOR_BORDER,
                           COLOR_TEXT_PRIMARY, COLOR_TEXT_ON_PRIMARY, COLOR_PRIMARY)
from ui.components.buttons import EnterpriseButton, ButtonVariant, ButtonSize


# Shared QComboBox stylesheet (used by type_filter and status_filter)
_COMBO_STYLE = f"""
    QComboBox {{ background-color: {COLOR_BG_SURFACE}; color: {COLOR_TEXT_PRIMARY};
        border: 1px solid {COLOR_BORDER}; border-radius: {BORDER_RADIUS_MD}px; padding: {SPACING_XS}px {SPACING_SM}px; }}
    QComboBox QAbstractItemView {{ background-color: {COLOR_BG_ELEVATED}; color: {COLOR_TEXT_PRIMARY};
        selection-background-color: {COLOR_PRIMARY}; selection-color: {COLOR_TEXT_ON_PRIMARY};
        border: 1px solid {COLOR_BORDER}; }}
"""


def _make_filter_combo(items, default_text="All", default_data="", min_width=120):
    """Create a styled filter QComboBox with items."""
    combo = QComboBox()
    combo.setStyleSheet(_COMBO_STYLE)
    combo.addItem(default_text, default_data)
    for label, data in items:
        combo.addItem(label, data)
    combo.setMinimumWidth(min_width)
    return combo


def build_filter_bar():
    """Build the filter bar widget. Returns (bar_widget, filter_refs_dict).

    filter_refs_dict has keys: type_filter, status_filter, date_from, date_to, search_input
    """
    bar = QGroupBox("Filters")
    bar.setStyleSheet(f"""
        QGroupBox {{
            border: 1px solid {COLOR_BORDER};
            border-radius: {BORDER_RADIUS_LG}px;
            margin-top: {SPACING_SM}px;
            padding-top: {SPACING_SM}px;
            color: {COLOR_TEXT_PRIMARY};
            font-size: {TEXT_LABEL}pt;
            font-weight: 700;
        }}
    """)
    layout = QHBoxLayout(bar)
    layout.setSpacing(SPACING_MD + SPACING_XS)

    refs = {}

    # Type filter
    type_layout = QVBoxLayout()
    type_layout.addWidget(QLabel("Entry Type:"))
    type_items = [(t, t) for t in
                  ["SALE", "PURCHASE", "PAYMENT", "RECEIPT", "ADJUSTMENT",
                   "TRANSFER", "OPENING", "CLOSING", "REVERSAL"]]
    refs["type_filter"] = _make_filter_combo(type_items, min_width=120)
    type_layout.addWidget(refs["type_filter"])
    layout.addLayout(type_layout)

    # Status filter
    status_layout = QVBoxLayout()
    status_layout.addWidget(QLabel("Status:"))
    status_items = [("Posted", "posted"), ("Draft", "draft")]
    refs["status_filter"] = _make_filter_combo(status_items, min_width=100)
    status_layout.addWidget(refs["status_filter"])
    layout.addLayout(status_layout)

    # Date range
    date_layout = QVBoxLayout()
    date_label_layout = QHBoxLayout()
    date_label_layout.addWidget(QLabel("From:"))
    refs["date_from"] = QDateEdit()
    refs["date_from"].setCalendarPopup(True)
    refs["date_from"].setDisplayFormat("yyyy-MM-dd")
    date_label_layout.addWidget(refs["date_from"])

    date_label_layout.addWidget(QLabel("To:"))
    refs["date_to"] = QDateEdit()
    refs["date_to"].setCalendarPopup(True)
    refs["date_to"].setDisplayFormat("yyyy-MM-dd")
    date_label_layout.addWidget(refs["date_to"])
    date_layout.addLayout(date_label_layout)
    layout.addLayout(date_layout)

    # Search
    search_layout = QVBoxLayout()
    search_layout.addWidget(QLabel("Search:"))
    refs["search_input"] = QLineEdit()
    refs["search_input"].setPlaceholderText("Entry # or description...")
    refs["search_input"].setMinimumWidth(200)
    refs["search_input"].setMinimumHeight(30)
    search_layout.addWidget(refs["search_input"])
    layout.addLayout(search_layout)

    # Apply button
    btn_apply = EnterpriseButton(
        text="Apply Filters",
        variant=ButtonVariant.SECONDARY,
        size=ButtonSize.MEDIUM
    )
    refs["btn_apply"] = btn_apply
    btn_layout = QVBoxLayout()
    btn_layout.addStretch()
    btn_layout.addWidget(btn_apply)
    layout.addLayout(btn_layout)

    return bar, refs


def build_filter_params(type_filter, status_filter, search_input):
    """Build API query params from filter widget state."""
    params = {"page_size": 100}

    type_val = type_filter.currentData()
    if type_val:
        params["entry_type"] = type_val

    status_val = status_filter.currentData()
    if status_val == "posted":
        params["is_posted"] = "true"
    elif status_val == "draft":
        params["is_posted"] = "false"

    search = search_input.text().strip()
    if search:
        params["search"] = search

    return params


def transform_entries(raw_entries):
    """Transform raw API entry dicts into table row dicts.

    Returns list of row dicts with display values and hidden metadata.
    """
    rows = []
    for entry in raw_entries:
        if not isinstance(entry, dict):
            continue

        is_posted = entry.get("is_posted") or False
        debit = safe_float(entry.get("total_debit"))
        credit = safe_float(entry.get("total_credit"))
        description = entry.get("description") or ""
        rows.append({
            "entry_number": entry.get("entry_number") or "",
            "entry_date": entry.get("entry_date") or "",
            "entry_type": entry.get("entry_type") or "",
            "description": description[:60] if len(description) > 60 else description,
            "debit": f"{debit:,.2f}",
            "credit": f"{credit:,.2f}",
            "status": "Posted" if is_posted else "Draft",
            "reference": entry.get("reference") or "",
            "id": entry.get("id"),
            "is_posted": is_posted,
            "_debit_value": debit,
            "_credit_value": credit,
        })
    return rows
