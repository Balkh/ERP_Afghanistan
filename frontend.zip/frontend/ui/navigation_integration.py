"""
Recent Items & Pinned Items System - Integration Module

Simple integration that extends the existing navigation system
for recent screens and pinned items functionality.

This module integrates with the existing NavigationHistory system
and provides enhanced navigation features.
"""

from .navigation_history import NavigationHistory
from .recent_items_integration import get_recent_items_integration


class NavigationIntegration:
    """Integration layer for recent items functionality."""
    
    def __init__(self, navigation_history: NavigationHistory, storage=None):
        self._navigation_history = navigation_history
        self._storage = storage if storage is not None else get_recent_items_integration()
        
        # Connect to existing navigation system
        self._setup_navigation_hooks()
    
    def _setup_navigation_hooks(self):
        """Setup hooks to track navigation for recent items."""
        # Override the push method to track recent items
        original_push = self._navigation_history.push
        
        def tracked_push(index: int, title: str) -> None:
            # Call original method
            original_push(index, title)
            
            # Track as recent item - Use screen_id derived from title
            # Ensure screen_id is valid and unique
            screen_id = self._generate_screen_id(title)
            self._storage.add_recent_screen(index, title, screen_id)
        
        self._navigation_history.push = tracked_push
    
    def _generate_screen_id(self, title: str) -> str:
        """
        Generate a valid screen ID from title.
        
        Args:
            title: Screen title
            
        Returns:
            Valid screen ID suitable for storage
        """
        if not title:
            return "unknown_screen"
        
        # Convert to lowercase, replace spaces with underscores
        screen_id = title.lower().replace(" ", "_")
        
        # Remove invalid characters
        import re
        screen_id = re.sub(r'[^a-z0-9_]', '', screen_id)
        
        # Ensure it's not empty
        if not screen_id:
            screen_id = "screen"
        
        return screen_id
    
    def handle_navigation_change(self, index: int, page_title: str) -> None:
        """Handle navigation changes and update recent items."""
        # Generate a proper screen_id from page_title
        screen_id = self._generate_screen_id(page_title)
        self._storage.add_recent_screen(index, page_title, screen_id)


def setup_recent_items_system():
    """Setup the recent items system in the application."""
    # This function would be called from main_window.py
    # to integrate the recent items system with existing navigation
    
    # The integration would be done in main_window.py like:
    # from ui.navigation_integration import setup_recent_items_system
    # setup_recent_items_system()
    
    pass


# Convenience functions for easy access
def add_recent_screen(index: int, title: str, screen_id: str) -> None:
    """Add screen to recent items."""
    from .recent_items_integration import add_recent_screen as storage_add
    storage_add(index, title, screen_id)

def toggle_pin(item_type: str, item_id: str, title: str) -> bool:
    """Toggle pin state for an item."""
    from .recent_items_integration import toggle_pin as storage_toggle
    return storage_toggle(item_type, item_id, title)

def is_pinned(item_type: str, item_id: str) -> bool:
    """Check if item is pinned."""
    from .recent_items_integration import is_pinned as storage_is_pinned
    return storage_is_pinned(item_type, item_id)


def get_recent_screens():
    """Get recent screens."""
    from .recent_items_integration import get_recent_screens as storage_get
    return storage_get()


def get_pinned_items(item_type: str):
    """Get pinned items."""
    from .recent_items_integration import get_pinned_items as storage_get
    return storage_get(item_type)